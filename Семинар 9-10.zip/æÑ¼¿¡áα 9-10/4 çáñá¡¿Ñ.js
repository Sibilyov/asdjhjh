function min(a, b) {
    return ( a > b ? b : a );
  }

  console.log(min(35, 100)); // → 0
  console.log(min(35, -25)); // → -10

  document.write(min(0, 10),' и ',min(0, -10));
