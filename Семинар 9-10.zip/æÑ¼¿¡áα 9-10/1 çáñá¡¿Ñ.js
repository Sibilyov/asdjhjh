var str = "#";
while (str.length<=7){
	console.log(str + "\n");
	str+="#";
}
